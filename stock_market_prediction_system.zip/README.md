# Stock Market Prediction System

A Streamlit-based Data Science and Machine Learning project for analyzing historical stock-market data and forecasting future closing prices.

## Features

- Yahoo Finance historical data
- CSV upload option
- Data cleaning and preprocessing
- Price trend analysis
- Trading-volume analysis
- 20-day and 50-day moving averages
- Correlation analysis
- Random Forest Regression
- Chronological 80/20 train-test split
- MAE, MSE, RMSE and R² evaluation
- Actual vs predicted chart
- 7–30 trading-day recursive forecast
- Forecast CSV download

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## CSV format

Your CSV should contain:

`Date, Open, High, Low, Close, Volume`

Example:

```csv
Date,Open,High,Low,Close,Volume
2025-01-02,100,103,99,102,1500000
2025-01-03,102,105,101,104,1700000
```

## Streamlit Community Cloud

1. Create a GitHub repository.
2. Upload `app.py` and `requirements.txt` to the repository root.
3. Open Streamlit Community Cloud.
4. Connect GitHub.
5. Create an app.
6. Select the repository and `app.py`.
7. Deploy.

The `requirements.txt` file is important because it tells Streamlit Cloud which external Python packages to install.
